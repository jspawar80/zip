const { authJwt } = require("../middleware");
const { verifySignUp } = require("../middleware");
const { commonMiddleware } = require("../middleware");
const { uploadfileMiddleware } = require("../middleware");
const AuthController = require("../controllers/auth.controller");
const AdminController = require("../controllers/admin.controller");
const db = require("../models");
const User = db.user;
const Coupon = db.coupon;
var express = require('express');
const session = require("express-session");
const { where } = require("sequelize");

var router = express.Router();

router.get('/register', (req, res) => {
  res.render('backend/register'); 
});

router.post('/register',[
  verifySignUp.checkDuplicateEmail,
  verifySignUp.checkRolesExisted
],AuthController.signup )

router.get('/login', (req, res) => {
  var flashmsg = req.flash('message');
  res.render('backend/login', {flash: flashmsg }); 
});

router.post('/login', authJwt.isAdmin,  AuthController.signin)

router.get('/dashboard', commonMiddleware.isSession, (req, res) => {
      res.render('backend/dashboard', {session: req.session.user});
});

router.get('/logout', (req, res) => {
  req.session.destroy(() => {
      res.redirect('login');
  });
});

router.post('/profile', commonMiddleware.isSession, AdminController.updateProfile);

router.get('/profile', commonMiddleware.isSession, (req, res) => {
  User.findOne({
    where: {
      id: req.session.user.id
    }
  })      
  .then(user => {
    if (!user) {
      return res.status(404).send({ message: "User Not found." });
    }
    var flashmsg = req.flash('message');
    // console.log(flashmsg);
    res.render('backend/profile', { session: user, pageName: "Profile", flash: flashmsg });
  });

});

router.post('/upload', uploadfileMiddleware.uploadImage.single('image'), AdminController.uploadAvatar);

// user management........................

router.get('/user-list', commonMiddleware.isSession, AdminController.userList);

// Soft delete a user
router.delete('/delete-user/:id', commonMiddleware.isSession, AdminController.deleteUser);

// coupon management ................

router.get('/coupon-list', commonMiddleware.isSession, AdminController.couponList);

router.get('/add-coupon', commonMiddleware.isSession,  (req, res) => {
  res.render('backend/coupons/add-coupon', { session: req.session.user, pageName: "Add New Coupon", })
});

router.post('/store-coupon', commonMiddleware.isSession, uploadfileMiddleware.uploadImage.single('logo'), AdminController.storeCoupon);

// Soft delete a coupon
router.delete('/delete-coupon/:id', commonMiddleware.isSession, AdminController.deleteCoupon);

// edit coupon
router.get('/edit-coupon/:id', commonMiddleware.isSession, AdminController.editCoupon);

// update coupon
router.post('/update-coupon/:id', commonMiddleware.isSession, uploadfileMiddleware.uploadImage.single('logo'), AdminController.couponUpdate);

// coupon give panel
router.get('/coupon-give', commonMiddleware.isSession, AdminController.giveCoupon);

// filter user to give coupon and coin
router.get('/filter-user', commonMiddleware.isSession, AdminController.filterUser);

router.post('/send-coupon', commonMiddleware.isSession, AdminController.sendCoupon);

router.post('/send-coin', commonMiddleware.isSession, AdminController.sendCoin);

router.get('/user-coupons', commonMiddleware.isSession, AdminController.userCoupons);

router.get('/user-coins', commonMiddleware.isSession, AdminController.userCoins);

module.exports = router;