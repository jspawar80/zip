const db = require("../models");
const config = require("../config/auth.config");
const User = db.user;
const Role = db.role;
const Session = db.session;

const Op = db.Sequelize.Op;
const crypto = require('crypto');

var jwt = require("jsonwebtoken");
var bcrypt = require("bcryptjs");

exports.signup = async (req, res) => {
  try {
    if (req.body.password !== '') {
      // Generate a unique 6-character code
      const characters = "0123456789";
      let code = '';
      for (let i = 0; i < 6; i++) {
        const randomIndex = crypto.randomInt(0, characters.length);
        code += characters.charAt(randomIndex);
      }
      // You can use this code for your email-related task
      console.log('Unique Code:', code);
      const users = await User.findByPk(code)
      if(users){
        code += characters.charAt(randomIndex);
      };

      const user = await User.create({
        name: req.body.name,
        email: req.body.email,
        invite_code: code,
        password: bcrypt.hashSync(req.body.password, 8)
      });

      if (req.body.roles) {
        const roles = await Role.findAll({
          where: {
            name: {
              [Op.or]: req.body.roles
            }
          }
        });
        await user.setRoles(roles);
        res.send({ message: "User registered successfully!" });
      } else {
        // user role = 1
        await user.setRoles([1]);
        console.log("User registered successfully!");
        res.redirect('login');
      }
    } else {
      res.send({ message: "please enter the password" });
    }
  } catch (err) {
    res.status(500).send({ message: err.message });
  }
};

exports.signin = (req, res) => {
  User.findOne({
    where: {
      email: req.body.email
    }
  })
    .then(user => {
      if (!user) {
        return res.status(404).send({ message: "User Not found." });
      }

      var passwordIsValid = bcrypt.compareSync(
        req.body.password,
        user.password
      );

      if (!passwordIsValid) {
        return res.status(401).send({
          accessToken: null,
          message: "Invalid Password!"
        });
      }

      if (user) {
        req.session.user = user; // Store user data in the session
        res.redirect('dashboard');
      } else {
          res.send('please enter valid information');
      }
      
    })
    .catch(err => {
      res.status(500).send({ message: err.message });
    });
};

exports.signout = async (req, res) => {
  try {
    req.session = null;
    return res.status(200).send({
      message: "You've been signed out!"
    });
  } catch (err) {
    this.next(err);
  }
};
