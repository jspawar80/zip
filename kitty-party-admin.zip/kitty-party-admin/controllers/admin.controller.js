const db = require("../models");
const config = require("../config/auth.config");
const User = db.user;
const Coupon = db.coupon;
const Role = db.role;
const Session = db.session;
const UserCoupon = db.usercoupon;
const UserCoin = db.usercoin;
const { Sequelize, DataTypes } = require('sequelize');

const Op = db.Sequelize.Op;

// get today date only and format is yyyy-mm-dd
var todayDate = new Date().toISOString().slice(0, 10);

exports.updateProfile = (req, res) => {
    // console.log(req.session.user.id);
    User.findOne({
        where: {
          id: req.session.user.id
        }
      })
      .then(user => {
        if (!user) {
          return res.status(404).send({ message: "User Not found." });
        }
        // console.log(user.id);
        User.update({ name: req.body.name, dob: req.body.dob, location: req.body.location, profession: req.body.profession }, {
            where: {
              id: user.id,
            },
          });
          req.flash('message', {'success': 'Successfully Profile Updated !!'});
          res.redirect('profile');
        // return res.status(200).send({ message: "Update profile success" });
      })
      .catch(err => {
        res.status(500).send({ message: err.message });
      });
};

exports.uploadAvatar = async (req, res) => {
  try {
    // Save the image name to the database
    const imageName = req.file.filename;
    const userId = req.session.user.id;
    console.log(userId);
    await User.update({ profile_image: imageName }, { where: { id: userId } });
      res.status(201).json({ success: 'Image uploaded successfully' });
  } catch (error) {
      res.status(500).json({ error: 'Error uploading the image' });
  }
};

exports.userList = async (req, res) => {
  try {
    const users = await User.findAll();
    if (users.length === 0) {
      return res.render('backend/users/user-list', {
        pageName: "User List",
        message: "User not Found"
      });
    }
    const userarr = [];
    // Use for...of loop to execute the operations sequentially
    for (const user of users) {
      const userss = await User.findByPk(user.id);
      const roles = await user.getRoles();

      for (let i = 0; i < roles.length; i++) {
        if (roles[i].role === "user") {
          userarr.push(userss);
        }
      }
    }
    res.render('backend/users/user-list', {
      session: req.session.user,
      userlist: userarr,
      pageName: "User List",
      message: "User not Found"
    });
  } catch (error) {
    // Handle any errors that may occur during the database queries.
    // console.error(error);
    res.status(500).send("Internal Server Error");
  }
}

exports.deleteUser =  async (req, res) => {
  // console.log(req.params.id);
  const userId = req.params.id;
  try {
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    // Mark the user as deleted by setting the deletedAt timestamp
    await User.update({ deletedAt: new Date() }, {
      where: {
        id: user.id,
      },
    });
    return res.json({ message: 'User has been soft deleted' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }
};

exports.couponList = async (req, res) => {
  try{
    const coupons = await Coupon.findAll();
    if (coupons.length === 0) {
      var flashmsg = req.flash('message');
      return res.render('backend/coupons/coupon-list', {
        session: req.session.user,
        pageName: "Coupon List",
        message: "Coupon not Found",
        flash: flashmsg,
      });
    }
    // console.log(coupons);
    var flashmsg = req.flash('message');
    res.render('backend/coupons/coupon-list', {
      session: req.session.user,
      couponlist: coupons,
      pageName: "Coupon List",
      message: "Coupon Found Successfull",
      flash: flashmsg,
    });    
  } catch (error) {
    // Handle any errors that may occur during the database queries.
    // console.error(error);
    res.status(500).send("Internal Server Error");
  }
};

exports.storeCoupon = async (req, res) => {
  try {
    // Save the image name to the database
    const { title, description, validity_start, validity_end, code, price } = req.body;
    const logo = req.file.filename;
    await Coupon.create({ logo, title, description, validity_start, validity_end, code, price});
      req.flash('message', {'success': 'Image uploaded successfully !!'});
      res.status(201).redirect('coupon-list');
  } catch (error) {
      req.flash('message', {'error': 'Error uploading the image !!'});
      res.status(500).redirect('coupon-list');
  }
};

exports.deleteCoupon =  async (req, res) => {
  // console.log(req.params.id);
  const couponId = req.params.id;
  try {
    const coupon = await Coupon.findByPk(couponId);
    if (!coupon) {
      return res.status(404).json({ message: 'Coupon not found' });
    }
    // Mark the user as deleted by setting the deletedAt timestamp
    await Coupon.update({ deletedAt: new Date() }, {
      where: {
        id: coupon.id,
      },
    });
    return res.json({ message: 'Coupon has been soft deleted' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }
};

exports.editCoupon =  async (req, res) => {
  // console.log(req.params.id);
  const couponId = req.params.id;
  try{
    const coupon = await Coupon.findOne({
      where: {
        id: couponId
      }
    });
    if (!coupon) {
      return res.status(404).json({ message: 'Coupon not found' });
    }
    // console.log(coupon);
    res.status(201).render('backend/coupons/edit-coupon.pug', { couponId ,session: req.session.user, coupon:coupon, pageName: "Coupon Edit"});
  } catch (error) {
    // console.error(error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }
};

exports.couponUpdate =  async (req, res) => {
  try {
    const couponId = req.params.id;
    const coupon = await Coupon.findByPk(couponId);
      if (!coupon) {
        return res.status(404).json({ message: 'Coupon not found' });
      }    
      var logo = coupon.logo;
      // Save the image name to the database
      var { title, description, validity_start, validity_end, code, price } = req.body;
      console.log(req.body);
      if(req.file){
        var logo = req.file.filename;
      }
      await Coupon.update({ logo, title, description, validity_start, validity_end, code, price}, {where:  { id: couponId } });
        req.flash('message', {'success': 'Coupon updated successfully !!'});
        res.status(201).redirect('/admin/coupon-list');
  } catch (error) {
      req.flash('message', {'error': 'Error updating coupon !!'});
      res.status(500).redirect('/admin/coupon-list');
  }

}

const getUniqueLocations = async () => {
  try {
    // Use the `distinct` option to get unique locations
    const uniqueLocations = await User.findAll({
      attributes: [[Sequelize.fn('DISTINCT', Sequelize.col('location')), 'location']],
    });
    
    // Extract the location values from the result
    const uniqueLocationValues = uniqueLocations.map((location) => location.dataValues.location);

    return uniqueLocationValues;
  } catch (error) {
    console.error('Error fetching unique locations:', error);
    throw error;
  }
};

exports.giveCoupon = async (req, res) => {
  try {
    const users = await User.findAll();
    if (users.length === 0) {
      return res.render('backend/coupons/coupon-give', {
        pageName: "User List",
        message: "User not Found"
      });
    }
    const userarr = [];
    // Use for...of loop to execute the operations sequentially
    for (const user of users) {
      const userss = await User.findByPk(user.id);
      const roles = await user.getRoles();

      for (let i = 0; i < roles.length; i++) {
        if (roles[i].role === "user") {
          userarr.push(userss);
        }
      }
    }

    // unique dob
    const uniquedob = await User.findAll({
      attributes: [ [Sequelize.fn('DISTINCT', Sequelize.col('dob')), 'dob'] ]
    });

    const dobValues = uniquedob.map(loc => loc.get('dob'));

    // unique location
    const uniqueLocations = await User.findAll({
      attributes: [
        [Sequelize.fn('DISTINCT', Sequelize.col('location')), 'location']
      ]
    });

    const locationValues = uniqueLocations.map(loc => loc.get('location'));

    // unique profession
    const uniqueProfession = await User.findAll({
      attributes: [
        [Sequelize.fn('DISTINCT', Sequelize.col('profession')), 'profession']
      ]
    });

    const professionValues = uniqueProfession.map(loc => loc.get('profession'));

    // unique next date
    const uniqueNextdate = await User.findAll({
      attributes: [
        [Sequelize.fn('DISTINCT', Sequelize.col('due_date')), 'due_date']
      ]
    });

    const NextdateValues = uniqueNextdate.map(loc => loc.get('due_date'));

    const couponlist = await Coupon.findAll();
    const validcoupons = [];
    for (const coupon of couponlist) {
        if(todayDate >= coupon.validity_start && todayDate <= coupon.validity_end){
          validcoupons.push(coupon);
        }
    }

    res.render('backend/coupons/coupon-give', {
      session: req.session.user,
      userlist: userarr,
      uniquelocation: locationValues,
      uniquedob: dobValues,
      uniqueprofession: professionValues,
      uniquenextdate: NextdateValues,
      validcoupons: validcoupons,
      pageName: "Give Coupon",
      message: "User not Found"
    });
  } catch (error) {
    // Handle any errors that may occur during the database queries.
    // console.error(error);
    res.status(500).send("Internal Server Error");
  }
}

exports.filterUser = async (req, res) => {
  try {
    const { location, profession, dob, due_date, startdate, enddate } = req.query;
    const filterOptions = {};
    if (location) {
      filterOptions.location = location;
    }
    if (profession) {
      filterOptions.profession = profession;
    }
    if (dob) {
      filterOptions.dob = dob;
    }

    if (due_date) {
      filterOptions.due_date = due_date;
    }
    
    if (startdate && enddate) {
      // filter due date based on range between method 
      const range = {[Op.between]: [startdate, enddate]};
      filterOptions.due_date = range;
    }

    const users = await User.findAll({
      where: filterOptions,
    });

    console.log(filterOptions);


    if (users.length === 0) {
      return res.json({
        error: "User not Found"
      });
    }
    const userarr = [];
    // Use for...of loop to execute the operations sequentially
    for (const user of users) {
      const userss = await User.findByPk(user.id);
      const roles = await user.getRoles();

      for (let i = 0; i < roles.length; i++) {
        if (roles[i].role === "user") {
          userarr.push(userss);
        }
      }
    }

    res.json(userarr);
  } catch (err) {
    // console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
};

exports.sendCoupon = async (req, res) => {
  try {
    // console.log(req.body);
    // Access the 'user_ids[]' key and store its value in a variable
    const userIDs = req.body['user_ids[]'];
    const couponId = req.body.coupon_id;
    const triggerdate = req.body.triggerdate;
    var triggerDate = '';

    // console.log(userIDs, couponId, triggerdate); // This will print the array [ '2', '3', '4', '5', '6', '7' ]
    // Create a new table to store user data
    const newTableData = [];

    for (const userID of userIDs) {
      // Find user data for each user ID
      const user = await User.findOne({
        where: {
          id: userID,
        }
      });

      if (user) {

        if(triggerdate == 'Next Date'){
          triggerDate = user.due_date;
        }

        if(triggerdate == 'DOB'){
          triggerDate = user.dob;
        }

        if(triggerDate == ''){
          triggerDate = triggerdate;
        }
        // Add user data to the new table
        newTableData.push({
          user_id: user.id,
          coupon_id: couponId,
          trigger_date: triggerDate,
        });
      }
    }

    console.log(newTableData);

    // Insert newTableData into your new table using the appropriate ORM or database query
    // For example, if you are using Sequelize:
    const userCoupons = await UserCoupon.bulkCreate(newTableData);
    if(userCoupons){
      res.json(newTableData);
    }
    // console.log(user);

  }
  catch (err) {
    // console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
};

exports.sendCoin = async (req, res) => {
  try {
    // console.log(req.body);
    // Access the 'user_ids[]' key and store its value in a variable
    const userIDs = req.body['user_ids[]'];
    const coin = req.body.coin;
    const triggerdate = req.body.triggerdate;
    var triggerDate = '';

    // console.log(userIDs, couponId, triggerdate); // This will print the array [ '2', '3', '4', '5', '6', '7' ]
    // Create a new table to store user data
    const newTableData = [];

    for (const userID of userIDs) {
      // Find user data for each user ID
      const user = await User.findOne({
        where: {
          id: userID,
        }
      });

      if (user) {

        if(triggerdate == 'Next Date'){
          triggerDate = user.due_date;
        }

        if(triggerdate == 'DOB'){
          triggerDate = user.dob;
        }

        if(triggerDate == ''){
          triggerDate = triggerdate;
        }
        // Add user data to the new table
        newTableData.push({
          user_id: user.id,
          coin: coin,
          trigger_date: triggerDate,
        });
      }
    }

    // console.log(newTableData);

    // Insert newTableData into your new table using the appropriate ORM or database query
    // For example, if you are using Sequelize:
    const userCoin = await UserCoin.bulkCreate(newTableData);

    if(userCoin){
      res.json(newTableData);
    }
    // console.log(user);

  }
  catch (err) {
    // console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
};

exports.userCoupons = async (req, res) => {
  try {
    const usercoupon = await UserCoupon.findAll();
    if (usercoupon.length === 0) {
      return res.render('backend/users/user-coupons', {
        pageName: "User Coupons",
        message: "User Coupons not Found"
      });
    }

    console.log(usercoupon);
    res.send("find user coupons");
    // res.render('backend/users/user-coupons', {
    //   session: req.session.user,
    //   usercoupon: usercoupon,
    //   pageName: "User Coupons",
    //   message: "User Coupons not Found"
    // });

  }
  catch (err) {
    // console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
};

exports.userCoins = async (req, res) => {
  try {
    const usercoin = await UserCoin.findAll();
    if (usercoin.length === 0) {
      return res.render('backend/users/user-coins', {
        pageName: "User Coins",
        message: "User Coins not Found"
      });
    }

    console.log(usercoin);
    res.send("find user coins");
    // res.render('backend/users/user-coupons', {
    //   session: req.session.user,
    //   usercoin: usercoin,
    //   pageName: "User Coupons",
    //   message: "User Coupons not Found"
    // });

  }
  catch (err) {
    // console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
};