module.exports = {
    secret: "kittyparty-secret-key"
  };