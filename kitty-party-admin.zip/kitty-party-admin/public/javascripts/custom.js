$(document).ready(function(){
    // flash message timeout
    setTimeout(function() {
        $('#flashMessage').fadeOut('fast');
    }, 3000);

    $("#select-all").click(function () {
      $(".row-checkbox").prop('checked', this.checked);
    });

    $("#triggerdate").change(function () {
      const trigger = $('#triggerdate').val();
      if(trigger == "Specific Date"){
        $('.specificdate').removeClass('d-none')
      }
      else{
        $('#specificdate').val('');
        $('.specificdate').addClass('d-none')
      }
    });

    $("#triggerdate1").change(function () {
      const trigger = $('#triggerdate1').val();
      if(trigger == "Specific Date"){
        $('.specificdate1').removeClass('d-none')
      }
      else{
        $('#specificdate1').val('');
        $('.specificdate1').addClass('d-none')
      }
    });



    $('#uploadAvatar').click(function () {
        const formData = new FormData();
        const fileInput = $('#imageInput')[0].files[0];
        formData.append('image', fileInput);

        $.ajax({
          type: 'POST',
          url: 'upload',
          data: formData,
          processData: false,
          contentType: false,
          success: function (data) {
            alert(data.success);
            location.reload(true);

          },
          error: function (err) {
            alert("error: Image upload error");
          },
        });
      });

    //   user filter based on required parameters
      $('#filterButton').click(function() {
        const dob = $('#dob').val();
        const location = $('#location').val();
        const profession = $('#profession').val();
        const due_date = $('#due_date').val();
        const startdate = $('#startdate').val();
        const enddate = $('#enddate').val();
        $.get(`filter-user?location=${location}&profession=${profession}&dob=${dob}&due_date=${due_date}&startdate=${startdate}&enddate=${enddate}`, function(data) {
          // Update the table with the filtered data
          // You can use JavaScript to manipulate the DOM and display the results
            var i = 1;
            var html = '';
            if(data.error){
              html += `<tr><td class="text-center" colspan="8">${data.error}</td></tr>`;
            }
            if(!data.error){
            data.forEach(element => {
                html += `<tr>
                <td><input type="checkbox" class="row-checkbox"></td>
                <td>
                  <i class="fab fa-angular fa-lg"></i>
                  <span class="fw-medium">${i++}</span>
                </td>
                <td>
                  <div class="avatar avatar-xs pull-up" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" aria-label="Sophia Wilkerson" data-bs-original-title="Sophia Wilkerson">
                    <img class="rounded-circle" src="/public/sneat/assets/img/avatars/6.png" alt="Avatar">
                  </div>
                </td>
                <td>
                  <span class="me-1">${element.name}</span>
                </td>
                <td>
                  <span class="me-1">${element.email}</span>
                </td>
                <td>
                  <span class="me-1">${element.uid}</span>
                </td>
                <td>
                  <span class="me-1">${element.location}</span>
                </td>
                <td class="d-flex">
                  <a class="text-dark" href="javascript:void(0);"><i class="bx bx-edit-alt me-1"></i></a>
                  <a class="text-dark" href="javascript:void(0)" onclick="deleteUser(${element.id})"><i class="bx bx-trash me-1"></i></a>
                </td>
              </tr>`;
            });

          };
                      
          $('#tbody').html(html);
          $('#select-all').prop('checked', false);
        });
      });



});

function sendcoupon(){

  var userids = []; 
  $("input:checked").map(function() { 
    userids.push($(this).attr('value')); 
  });

  if(userids == ''){
    alert("Please select any user");
  }
  else{
    // alert(userids);
    var couponid = $('#coupons option:selected').attr('value');
    // alert(couponid);
    var triggerdate = $('#triggerdate option:selected').attr('value');

    if(triggerdate == "Specific Date"){
      triggerdate = $('#specificdate').val();
    }
    // alert(triggerdate);
    $.ajax({
      method: 'POST',
      url: 'send-coupon',
      data: {
        user_ids: userids,
        coupon_id: couponid,
        triggerdate: triggerdate
      },
      success: function (response) {
        // console.log(response);
        alert('Coupon Given Successfully');
      },
      error: function (error) {
        // console.error(error);

        alert(error);
        alert('Error giving coupon user');
      },
    });

  }
}

function sendcoin(){

  var userids = []; 
  $("input:checked").map(function() { 
    userids.push($(this).attr('value')); 
  });

  if(userids == ''){
    alert("Please select any user");
  }
  else{
    // alert(userids);
    var coin = $('#coin').val();
    // alert(coin);
    var triggerdate = $('#triggerdate1 option:selected').attr('value');

    if(triggerdate == "Specific Date"){
      triggerdate = $('#specificdate1').val();
    }
    // alert(triggerdate);
    $.ajax({
      method: 'POST',
      url: 'send-coin',
      data: {
        user_ids: userids,
        coin: coin,
        triggerdate: triggerdate
      },
      success: function (response) {
        // console.log(response);
        alert('Coin Given Successfully');
      },
      error: function (error) {
        // console.error(error);
        alert(error);
        alert('Error giving coin user');
      },
    });

  }
}

function deleteUser(id) {
  // alert('delete-user/' + route);
  if (confirm('Are you sure you want to delete this user?')) {
      fetch('delete-user/' + id, {
              method: 'DELETE'
          })
          .then(response => {
              if (response.ok) {
                  // Handle success (e.g., show a success message)
                  alert('User deleted successfully');
                  location.reload(true);
              } else {
                  // Handle errors (e.g., show an error message)
                  alert('Failed to delete user');
              }
          })
          .catch(error => {
              console.error(error);
          });
  }
}

function deleteCoupon(id) {
  // alert('delete-user/' + route);
  if (confirm('Are you sure you want to delete this user?')) {
      fetch('delete-coupon/' + id, {
              method: 'DELETE'
          })
          .then(response => {
              if (response.ok) {
                  // Handle success (e.g., show a success message)
                  alert('Coupon deleted successfully');
                  location.reload(true);
              } else {
                  // Handle errors (e.g., show an error message)
                  alert('Failed to delete coupon');
              }
          })
          .catch(error => {
              console.error(error);
          });
  }
}
