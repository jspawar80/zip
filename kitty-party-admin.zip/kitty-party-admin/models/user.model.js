module.exports = (sequelize, Sequelize) => {
  const User = sequelize.define("users", {
    name: {
      type: Sequelize.STRING
    },
    email: {
      type: Sequelize.STRING
    },
    password: {
      type: Sequelize.STRING
    },
    dob: {
      type: Sequelize.STRING
    },
    profession: {
      type: Sequelize.STRING
    },
    location: {
      type: Sequelize.STRING
    },
    profile_image: {
      type: Sequelize.STRING
    },
    invite_code: {
      type: Sequelize.STRING
    },
    referal_code: {
      type: Sequelize.STRING
    },
    isblocked: {
      type: Sequelize.BOOLEAN
    },
    due_date: {
      type: Sequelize.DATEONLY
    },
    deletedAt: {
      type: Sequelize.DATE,
      defaultValue: null, // Soft delete flag
    },
  },
  {
    paranoid: true, // Enable Paranoid mode
  });
  return User;
};