module.exports = (sequelize, Sequelize) => {
    const Role = sequelize.define("roles", {
      role: {
        type: Sequelize.STRING
      },
      deletedAt: {
        type: Sequelize.DATE,
        defaultValue: null, // Soft delete flag
      },
    },
    {
      paranoid: true, // Enable Paranoid mode
    });
    return Role;
  };