module.exports = (sequelize, Sequelize) => {
  const Session = sequelize.define("sessions", {
    email: {
      type: Sequelize.STRING
    },
    uid: {
      type: Sequelize.STRING
    },
    refreshtoken: {
      type: Sequelize.STRING
    }
  });
  return Session;
};