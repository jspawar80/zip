module.exports = (sequelize, Sequelize) => {
    const Tracker = sequelize.define("trackers", {
      user_id: {
        type: Sequelize.INTEGER
      },
      last_date: {
        type: Sequelize.DATEONLY
      },
      last_days: {
        type: Sequelize.INTEGER
      },
      cycle_days: {
        type: Sequelize.INTEGER
      },
      due_date: {
        type: Sequelize.DATEONLY
      },
      reset_reason: {
        type: Sequelize.STRING,
      },
      deletedAt: {
        type: Sequelize.DATE,
        defaultValue: null, // Soft delete flag
      },
    },
    {
      paranoid: true, // Enable Paranoid mode
    });
    return Tracker;
  };