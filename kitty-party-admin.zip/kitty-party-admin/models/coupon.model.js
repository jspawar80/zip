module.exports = (sequelize, Sequelize) => {
    const Coupon = sequelize.define("coupons", {
      logo: {
        type: Sequelize.STRING
      },
      title: {
        type: Sequelize.STRING
      },
      description: {
        type: Sequelize.STRING
      },
      validity_start: {
        type: Sequelize.DATEONLY
      },
      validity_end: {
        type: Sequelize.DATEONLY
      },
      code: {
        type: Sequelize.STRING
      },
      price: {
        type: Sequelize.INTEGER
      },
      deletedAt: {
        type: Sequelize.DATE,
        defaultValue: null, // Soft delete flag
      },
    },
    {
      paranoid: true, // Enable Paranoid mode
    });
    
    return Coupon;
  };