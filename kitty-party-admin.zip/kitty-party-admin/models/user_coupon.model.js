module.exports = (sequelize, Sequelize) => {
    const UserCoupon = sequelize.define("user_coupons", {
      user_id: {
        type: Sequelize.INTEGER
      },
      coupon_id: {
        type: Sequelize.INTEGER
      },
      trigger_date: {
        type: Sequelize.DATEONLY
      },
      isclaimed: {
        type: Sequelize.BOOLEAN
      },
      
      deletedAt: {
        type: Sequelize.DATE,
        defaultValue: null, // Soft delete flag
      },
    },
    {
      paranoid: true, // Enable Paranoid mode
    });
    
    return UserCoupon;
  };