module.exports = (sequelize, Sequelize) => {
    const UserCoin = sequelize.define("user_coins", {
      user_id: {
        type: Sequelize.INTEGER
      },
      coin: {
        type: Sequelize.INTEGER
      },
      trigger_date: {
        type: Sequelize.DATEONLY
      },
      isclaimed: {
        type: Sequelize.BOOLEAN
      },
      
      deletedAt: {
        type: Sequelize.DATE,
        defaultValue: null, // Soft delete flag
      },
    },
    {
      paranoid: true, // Enable Paranoid mode
    });
    
    return UserCoin;
  };