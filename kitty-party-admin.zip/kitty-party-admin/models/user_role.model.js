module.exports = (sequelize, Sequelize) => {
    const UserRole = sequelize.define("user_roles", {
      roleId: {
        type: Sequelize.INTEGER
      },
      userId: {
        type: Sequelize.INTEGER
      },
      deletedAt: {
        type: Sequelize.DATE,
        defaultValue: null, // Soft delete flag
      },
    },
    {
      paranoid: true, // Enable Paranoid mode
    });
    return UserRole;
  };