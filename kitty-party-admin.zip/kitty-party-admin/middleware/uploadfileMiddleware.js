const multer = require('multer');

const imageFilter = (req, file, cb) => {
    if (file.mimetype.startsWith("image")) {
      cb(null, true);
    } else {
      cb("Please upload only images.", false);
    }
  };

  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'public/uploads/images/'); // Define the destination folder for uploaded files
    },
    filename: (req, file, cb) => {
      cb(null, Date.now() + '-' + file.originalname); // add now() before filename
    },
  });
  
  const uploadImage = multer({
    storage: storage, imageFilter: imageFilter,
      limits: { fileSize: 1000000 }, // 1MB limit
  });

  
  const uploadfileMiddleware = {
    uploadImage: uploadImage
  };

  module.exports = uploadfileMiddleware;

