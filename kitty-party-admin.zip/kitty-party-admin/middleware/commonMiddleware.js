const jwt = require("jsonwebtoken");
const config = require("../config/auth.config.js");
const db = require("../models/index.js");
const User = db.user;

var bcrypt = require("bcryptjs");

isSession = (req, res, next) => {
    if(!req.session.user){
        req.flash('message', {'error': 'Invalid Session..!! Please Login.'});
        console.log("message: ", "redirtect to login");
        res.redirect('/admin/login');
    }
    else{
        next();
    }
  }

  const commonMiddleware = {
    isSession: isSession
  };
  module.exports = commonMiddleware;