# kitty-party-admin
Admin Panel of Kitty Party App

to start the project run the following command:

npm start


